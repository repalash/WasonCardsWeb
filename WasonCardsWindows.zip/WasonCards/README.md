# Wason Cards

Application by Palash Bansal, Satyam Kumar, and Milind Yadav from IIIT Delhi.

Use the application naturally, click on the cards you would like to flip and press the enter key on the keyboard.

